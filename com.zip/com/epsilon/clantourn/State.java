package com.epsilon.clantourn;

public enum State {
	START_COUNTDOWN,
	IN_PLAY;
}
