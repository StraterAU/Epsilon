package com.epsilon.world.content.random;

public interface RandomEvent {

	void spawn();
	
	void process();
	
}
