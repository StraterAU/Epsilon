package com.epsilon.world.content.skill.impl.farming;

public class Flower {
}
