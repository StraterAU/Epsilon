package com.epsilon.world.content.skill.impl.farming;

public class FarmingConstants {
	public static final int PLANT_SEED = 2291;
	public static final int RAKE = 2273;
	public static final int COMPOST = 2283;
	public static final int PICK_HERB = 2275;
	public static final int WATER = 2293;
	public static final int CURE_PLANT = 2288;
	public static final int SEED_DIBBER = 5343;
	public static final int RAKE_ITEM = 5341;
	public static final int SECATEURS = 5329;
	public static final int WATERING_CAN = 5331;
	public static final int DISEASE_CHANCE = 5;
}
