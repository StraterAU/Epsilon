package com.epsilon.model.input;

import com.epsilon.world.entity.impl.player.Player;


public class Input {
	
	public void handleSyntax(Player player, String text) {
		
	}

	public void handleAmount(Player player, int amount) {
		
	}
}
