package com.epsilon.model;

public enum GraphicHeight {

	LOW,
	
	MIDDLE,
	
	HIGH;
}
